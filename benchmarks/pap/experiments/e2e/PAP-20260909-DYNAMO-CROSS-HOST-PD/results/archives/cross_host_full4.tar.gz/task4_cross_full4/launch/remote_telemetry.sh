#!/usr/bin/env bash
set -euo pipefail
while true; do
  nvidia-smi \
    --query-gpu=timestamp,index,utilization.gpu,memory.used,power.draw \
    --format=csv,noheader,nounits
  sleep 1
done
