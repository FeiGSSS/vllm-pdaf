from pathlib import Path
import json,subprocess
ROOT=Path('/home/fei/research/PD/vllm-pap')
OUT=Path('/home/fei/research/PD/vllm-pap/benchmarks/pap/experiments/e2e/PAP-20260907-ALIGNED-C30/runs/20260907T020755Z')
HEAD='bdb0954c7593bb289733108397a83de94179b0cf'
for script,logname in [('run_aligned.py','driver-aligned.log'),('pap_clean/run.py','pap_clean/driver.log'),('summarize.py','summary.log')]:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD,'source revision changed'
    assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','vllm','benchmarks/pap/scripts'],cwd=ROOT,text=True).strip(),'runtime source changed'
    print('Starting '+script,flush=True)
    with (OUT/logname).open('w') as log:
        completed=subprocess.run([str(ROOT/'.venv/bin/python'),str(OUT/script)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    if completed.returncode:
        (OUT/'invalidated.json').write_text(json.dumps({'script':script,'exit_code':completed.returncode}))
        raise SystemExit(completed.returncode)
    print('Completed '+script,flush=True)
(OUT/'completed.json').write_text(json.dumps({'status':'passed','requests':1800,'runs':10}))
