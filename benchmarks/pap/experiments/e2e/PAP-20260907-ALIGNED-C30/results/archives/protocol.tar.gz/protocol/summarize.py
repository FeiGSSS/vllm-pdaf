from pathlib import Path
import hashlib
import json
import shlex
from statistics import mean,median

OUT=Path('/home/fei/research/PD/vllm-pap/benchmarks/pap/experiments/e2e/PAP-20260907-ALIGNED-C30/runs/20260907T020755Z')
RUNS=OUT/'runs_aligned'
PAP=OUT/'pap_clean'
INPUT_SHA='ece4ff1e413301990a84a1a4f43b7a65ae45b150c023a2f43e725c99ef7032c5'

def env(path):
    values={}
    for line in path.read_text().splitlines():
        if line and not line.startswith('#'):
            k,v=line.split('=',1);values[k]=shlex.split(v)[0]
    return values

def records(path):
    assert (path/'exit_code').read_text().strip()=='0',path
    assert json.loads((path/'startup_audit.json').read_text())['status']=='passed'
    assert json.loads((path/'cleanup_wait.json').read_text())['status']=='passed'
    assert 'STATUS=passed' in (path/'correctness_audit.env').read_text()
    assert hashlib.sha256((path/'aiperf/inputs.json').read_bytes()).hexdigest()==INPUT_SHA
    profile=json.loads((path/'aiperf/profile.json').read_text());assert not profile.get('error_summary')
    phases=profile['input_config']['phases']
    assert phases==[{'name':'profiling','type':'concurrency','sessions':60,'concurrency':30}], phases
    rows=[json.loads(x) for x in (path/'aiperf/profile.jsonl').read_text().splitlines()]
    assert len(rows)==180
    return rows

paths={a:[RUNS/f'{a}_r1',RUNS/f'{a}_r2'] for a in ['dp8','6p2d','4p4d','2p6d']}
paths['pap7pa1p']=[PAP/'run_pap1',PAP/'run_pap2']
reference=None;result={'workload':{'concurrency':30,'sessions':60,'turns':3,'requests_per_run':180,'input_sha256':INPUT_SHA,'model':'Qwen3-8B FP16','max_model_len':32768,'GPUs':'8 x L20'},'architectures':{}}
for arch,runs in paths.items():
    combined=[];individual=[];configs=[]
    for path in runs:
        rows=records(path);cfg=env(path/'effective_config.env');configs.append(cfg)
        index={(r['metadata']['conversation_id'],r['metadata']['turn_index']):r for r in rows}
        if reference is None:reference={k:r['metrics']['output_sequence_length'] for k,r in index.items()}
        assert index.keys()==reference.keys()
        assert all(r['metrics']['output_sequence_length']==reference[k] for k,r in index.items()),path
        if arch=='pap7pa1p':
            assert cfg['PAP_DYNAMO_PREFILL_LOAD_SCALE']=='2.0'
            for f in ['routing_audit.env','decode_token_join_audit.env','session_drain.env']:assert 'STATUS=passed' in (path/f).read_text()
            assert cfg['PAP_PREFILL_MAX_NUM_BATCHED_TOKENS']=='2048' and cfg['PAP_PROJECTION_MAX_NUM_BATCHED_TOKENS']=='256'
        else:
            assert cfg['DYNAMO_ROUTER_PREFILL_LOAD_SCALE']=='2.0'
            assert json.loads((path/'completion_audit.json').read_text())['status']=='passed'
            expected='STATUS=not_applicable' if arch=='dp8' else 'STATUS=passed'
            assert expected in (path/'kv_transfer_audit.env').read_text()
            assert cfg['DYNAMO_AGG_MAX_NUM_BATCHED_TOKENS']=='2048' and cfg['DYNAMO_PREFILL_MAX_NUM_BATCHED_TOKENS']=='2048' and cfg['DYNAMO_DECODE_MAX_NUM_BATCHED_TOKENS']=='256'
        one={'run':str(path),'requests':180}
        for metric in ['time_to_first_token','inter_token_latency']:
            vals=[r['metrics'][metric]['value'] for r in rows];one[metric+'_mean_ms']=mean(vals)
        one['client_span_s']=(max(r['metadata']['request_end_ns'] for r in rows)-min(r['metadata']['request_start_ns'] for r in rows))/1e9
        one['input_tokens']=sum(r['metrics']['input_sequence_length']['value'] for r in rows)
        individual.append(one);combined+=rows
    differences={k:[configs[0].get(k),configs[1].get(k)] for k in configs[0].keys()|configs[1].keys() if configs[0].get(k)!=configs[1].get(k)}
    permitted={'RUN_ROOT','RUN_LOG_DIR','PAP_AIPERF_OUTPUT_DIR'} if arch=='pap7pa1p' else {'NAMESPACE','DYNAMO_NAMESPACE','DYNAMO_RUN_ID','DYNAMO_RUN_ROOT','DYNAMO_AIPERF_OUTPUT_DIR','DYNAMO_FILE_KV'}
    assert set(differences)<=permitted,(arch,differences)
    summary={'runs':individual,'requests':360,'effective_config_differences_between_repetitions':differences}
    for metric in ['time_to_first_token','inter_token_latency']:
        vals=sorted(r['metrics'][metric]['value'] for r in combined)
        summary[metric]={'mean_ms':mean(vals),'p50_ms':median(vals),'p95_ms':vals[int(.95*len(vals))],'per_run_mean_range_ms':[min(x[metric+'_mean_ms'] for x in individual),max(x[metric+'_mean_ms'] for x in individual)]}
    summary['ttft_by_turn_ms']={str(t):mean(r['metrics']['time_to_first_token']['value'] for r in combined if r['metadata']['turn_index']==t) for t in range(3)}
    result['architectures'][arch]=summary
pap=result['architectures']['pap7pa1p']
for arch,item in result['architectures'].items():
    if arch!='pap7pa1p':item['pap_relative_change_percent']={k:100*(pap[k]['mean_ms']/item[k]['mean_ms']-1) for k in ['time_to_first_token','inter_token_latency']}
(OUT/'comparison.json').write_text(json.dumps(result,indent=2))
for arch,item in result['architectures'].items():
    print(arch,round(item['time_to_first_token']['mean_ms']/1000,3),'s TTFT',round(item['inter_token_latency']['mean_ms'],3),'ms TBT')
