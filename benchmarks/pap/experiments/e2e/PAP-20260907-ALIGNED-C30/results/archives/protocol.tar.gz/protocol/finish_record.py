from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
ROOT=Path('/home/fei/research/PD/vllm-pap')
OUT=Path('/home/fei/research/PD/vllm-pap/benchmarks/pap/experiments/e2e/PAP-20260907-ALIGNED-C30/runs/20260907T020755Z')
EXP=OUT.parent.parent
RES=EXP/'results'
OLD=ROOT/'benchmarks/pap/experiments/e2e/PAP-20260907-ALIGNED-DP-PD-PAP'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((OUT/'completed.json').read_text())['status']=='passed'
compare=json.loads((OUT/'comparison.json').read_text())
old=json.loads((OLD/'results/comparison.json').read_text())
comparison={'concurrency_30':compare,'concurrency_60_reference':str(OLD.relative_to(ROOT)),'changes_from_concurrency_60':{}}
for arch,item in compare['architectures'].items():
    comparison['changes_from_concurrency_60'][arch]={metric:100*(item[metric]['mean_ms']/old['architectures'][arch][metric]['mean_ms']-1) for metric in ('time_to_first_token','inter_token_latency')}
(OUT/'comparison_to_c60.json').write_text(json.dumps(comparison,indent=2)+'\n')
original=json.loads((OLD/'results/final_source_audit.json').read_text())
expected=json.loads((OUT/'source_manifest.json').read_text())|json.loads((OUT/'pap_source_reference.json').read_text())['source_sha256']
assert all(sha(ROOT/name)==value for name,value in expected.items())
(OUT/'final_source_audit.json').write_text(json.dumps({'status':'passed','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_sha256':expected},indent=2)+'\n')
apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader,nounits'],text=True)
assert not apps.strip(),apps
remaining=[]
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:command=(proc/'cmdline').read_bytes().replace(b'\x00',b' ').decode()
    except (OSError,UnicodeError):continue
    if any(marker in command for marker in ('dynamo.vllm','dynamo.frontend','dynamo-frontend','VLLM::EngineCore','vllm.pap.service','vllm.pap.gateway','/bin/vllm serve','/bin/aiperf')):
        remaining.append({'pid':int(proc.name),'command':command})
assert not remaining,remaining
(OUT/'final_cleanup_audit.json').write_text(json.dumps({'status':'passed','gpu_compute_processes':apps,'remaining_serving_processes':remaining})+'\n')
(RES/'archives').mkdir(parents=True,exist_ok=False)
manifest={'format':1,'source_root':str(OUT),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'concurrency':30,'requests_per_run':180,'total_requests':1800,'archives':[]}
def archive(name,entries):
    target=RES/'archives'/f'{name}.tar.gz'
    members=[]
    with target.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
        for path,member in entries:
            if path.is_dir():continue
            assert path.is_file() and not path.is_symlink(),path
            info=tar.gettarinfo(str(path),arcname=member)
            info.uid=info.gid=0;info.uname=info.gname=''
            with path.open('rb') as stream:tar.addfile(info,stream)
            members.append({'path':member,'bytes':path.stat().st_size,'sha256':sha(path)})
    manifest['archives'].append({'path':str(target.relative_to(RES)),'sha256':sha(target),'bytes':target.stat().st_size,'files':members,'omitted_nonregular':[]})
    print('Archived',name,len(members),'files',target.stat().st_size,'bytes',flush=True)
for relative in [f'runs_aligned/{a}_r{r}' for r in (1,2) for a in ('dp8','6p2d','4p4d','2p6d')]+['pap_clean/run_pap1','pap_clean/run_pap2']:
    run=OUT/relative
    archive(run.name,[(p,str(p.relative_to(OUT))) for p in sorted(run.rglob('*'))])
    exposed=RES/'configs'/run.name;exposed.mkdir(parents=True)
    for name in ('requested.env','effective_config.env','startup_audit.json','completion_audit.json','cleanup_wait.json'):
        if (run/name).exists():shutil.copyfile(run/name,exposed/name)
protocol=[(p,'protocol/'+p.name) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'archive.log']
protocol += [(p,'protocol/pap_clean/'+p.name) for p in sorted((OUT/'pap_clean').iterdir()) if p.is_file()]
archive('protocol',protocol)
for name in ('comparison.json','comparison_to_c60.json','parameter_alignment.json','final_source_audit.json','final_cleanup_audit.json','common.env','experiment_identity.json'):
    shutil.copyfile(OUT/name,RES/name)
(RES/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copyfile(OLD/'verify.py',EXP/'verify.py')
(EXP/'.gitignore').write_text('/runs/\n!results/**/*.json\n!results/**/*.log\n')
(EXP/'.gitattributes').write_text('# Preserve raw terminal output.\nresults/**/*.log -whitespace\n')
lines=['# DP / PD / PAP comparison at concurrency 30','',
'同一组五种架构各两次，共 10 次运行、1800 个请求；客户端并发从 60 改为 30，',
'会话数仍为 60，每会话三轮。模型、native-32K 数据集、调度预算和路由参数沿用上一组。','',
'| 架构 | TTFT (s) | TBT (ms) | TTFT 较 C60 | TBT 较 C60 |',
'| --- | ---: | ---: | ---: | ---: |']
for arch,item in compare['architectures'].items():
    delta=comparison['changes_from_concurrency_60'][arch]
    lines.append(f"| {arch} | {item['time_to_first_token']['mean_ms']/1000:.3f} | {item['inter_token_latency']['mean_ms']:.3f} | {delta['time_to_first_token']:+.2f}% | {delta['inter_token_latency']:+.2f}% |")
lines += ['',
'表中为两轮客户端逐请求指标的平均值，负百分比表示下降。TBT 使用 AIPerf',
'`inter_token_latency`，不是 GPU step 耗时。各轮值、p50、p95 和范围见',
'[comparison.json](results/comparison.json)；p95 沿用排序后 `int(0.95 * N)`。','',
'两轮客户端实际 phases 配置均为 sessions=60、concurrency=30；每轮 180 个请求。',
'输入文件哈希和各会话轮次输出长度相同；后续 prompt 含实际生成反馈。所有正式',
'运行均通过有效配置、启动拓扑、真实进程和 GPU 映射、正确性及清理审计。','',
'DP/PD 使用官方 Dynamo 1.4.1 / vLLM 0.26.0，PAP 使用提交 `bdb0954c75`。',
'与 C60 测量相比，该提交将回收边界的 CUDA 同步 API 换成 accelerator 同步 API，',
'此前已验证 CUDA 行为。因此这里是同负载的配置对比，不能声称严格单变量因果实验。',
'各架构的专有 Graph / 显存策略仍不同，两次重复不足以建立稳定优劣结论。','',
'没有配置 goodput SLO；原始逐请求延迟与时间戳保留，可后续统一阈值计算。','',
'## 原始记录与复核','',
'`results/archives/` 无损保留十次运行的全部普通文件及原始执行协议，',
'`results/configs/` 展示 requested/effective 配置和主要审计。逐文件 SHA256',
'见 `results/manifest.json`；结果总清单为 `results/SHA256SUMS`。','',
'从仓库根目录离线校验并复算：','',
'```bash',
'.venv/bin/python benchmarks/pap/experiments/e2e/PAP-20260907-ALIGNED-C30/verify.py',
'```','',
'附加 `--extract-to /tmp/pap-c30-restored` 可解压到一个尚不存在的目录。',
'原始协议和配置中的绝对路径用于追溯当时运行；不覆盖历史结果。新测量使用共享',
'runner，创建独立 `runs/<timestamp>/` 并沿用完整拓扑和配置审计。','']
(EXP/'README.md').write_text('\n'.join(lines))
(RES/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(RES)}\n' for p in sorted(RES.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
print('Final record:',EXP,flush=True)
