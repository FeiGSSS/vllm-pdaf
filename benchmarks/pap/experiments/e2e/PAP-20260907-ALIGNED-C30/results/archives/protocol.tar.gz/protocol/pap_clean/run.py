from pathlib import Path
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time
import urllib.request
import shlex
import re

ROOT = Path('/home/fei/research/PD/vllm-pap')
OUT = Path('/home/fei/research/PD/vllm-pap/benchmarks/pap/experiments/e2e/PAP-20260907-ALIGNED-C30/runs/20260907T020755Z/pap_clean')
MANIFEST = json.loads((OUT / 'source_manifest.json').read_text())
EXPECTED_DATA = '5d4357a9a037e9e1a3c25acf402ba06afd1c9e7643678da225b9f5cc63cb257c'
DATA = ROOT / 'benchmarks/pap/datasets/agentic-code/s60-t3-native32k-stratified-seed42/dataset.jsonl'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def processes():
    result = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            argv = (entry / 'cmdline').read_bytes().decode().split('\0')
            env = dict(row.split('=', 1) for row in (entry / 'environ').read_bytes().decode().split('\0') if '=' in row)
            command = ' '.join(argv).strip()
            if not command or not any(x in command for x in ('VLLM::EngineCore', 'dynamo.vllm', 'dynamo.frontend', 'dynamo-frontend', 'vllm.pap.service', 'vllm.pap.gateway', '/bin/vllm serve', '/bin/aiperf')):
                continue
            if 'ab_run.py' in command:
                continue
            selected = {key: env[key] for key in ('CUDA_VISIBLE_DEVICES', 'PAP_PROJECTION_KV_UNAWARE', 'PAP_RUNTIME_CUDA_CONTEXT_ROLE', 'CUDA_MPS_SM_PARTITION', 'PAP_NVSHMEM_RANK', 'PAP_NVSHMEM_WORLD_SIZE', 'RUN_ROOT') if key in env}
            ancestors = []
            parent = int(entry.name)
            while parent > 1:
                stat = Path(f'/proc/{parent}/stat').read_text()
                parent = int(stat.rsplit(')', 1)[1].split()[1])
                ancestors.append(parent)
            result.append({'pid': int(entry.name), 'command': command, 'env': selected, 'ancestors': ancestors})
        except (OSError, UnicodeError):
            continue
    return result

def audit(run, uuids, runner_pid):
    contexts = [json.loads(path.read_text()) for path in sorted(run.glob('runtime_cuda_context_*_*.json'))]
    assert len(contexts) == 14, len(contexts)
    assert len({row['pid'] for row in contexts}) == 14
    for role, sms in [('prefill', 80), ('attention', 12)]:
        for index in range(7):
            row = json.loads((run / f'runtime_cuda_context_{role}_{index}.json').read_text())
            assert row['role'] == role and row['multiprocessor_count'] == sms, row
            assert row['device_uuid'] == uuids[index], row
            assert Path(f'/proc/{row["pid"]}').exists(), row
    current = processes()
    (run / 'process_topology.json').write_text(json.dumps(current, indent=2))
    engines = [row for row in current if 'VLLM::EngineCore' in row['command']]
    assert len(engines) == 8, engines
    projections = [row for row in engines if row['env'].get('PAP_PROJECTION_KV_UNAWARE') == '1']
    assert len(projections) == 1 and projections[0]['env']['CUDA_VISIBLE_DEVICES'] == '7', projections
    assert {row['pid'] for row in engines} == {row['pid'] for row in contexts if row['role'] == 'prefill'} | {projections[0]['pid']}
    attention = [row for row in current if '-m vllm.pap.service' in row['command']]
    assert len(attention) == 7, attention
    assert not any('/bin/aiperf' in row['command'] for row in current), 'unexpected client before audit'
    assert all(runner_pid in row['ancestors'] for row in current), 'service outside runner process tree'
    budget_line = next(x for x in (run / 'requested.env').read_text().splitlines() if x.startswith('PAP_PREFILL_MAX_NUM_BATCHED_TOKENS='))
    expected_budget = int(budget_line.split('=', 1)[1])
    for index in range(7):
        servers = [shlex.split(row['command']) for row in current if '/bin/vllm serve' in row['command']]
        servers = [args for args in servers if '--port' in args and args[args.index('--port') + 1] == str(8100 + index)]
        assert len(servers) == 1, f'Prefill {index} server process missing'
        args = servers[0]
        assert args[args.index('--max-num-batched-tokens') + 1] == str(expected_budget), f'Prefill {index} process budget mismatch'
        log = (run / 'service_logs' / f'prefill_{index}.log').read_text(errors='replace')
        assert set(re.findall(r"'max_num_batched_tokens': (\d+)", log)) == {str(expected_budget)}, f'Prefill {index} parsed budget mismatch'
        assert set(re.findall(r'enable_chunked_prefill=(True|False)', log)) == {'True'}, f'Prefill {index} EngineCore chunked prefill disabled'
    (run / 'prefill_budget_audit.json').write_text(json.dumps({'status': 'passed', 'max_num_batched_tokens': expected_budget, 'ranks': 7}, indent=2))
    (run / 'startup_audit.json').write_text(json.dumps({'status': 'passed', 'gpu_contexts': contexts, 'engine_count': len(engines), 'attention_count': len(attention)}, indent=2))

def wait_for_gpu_cleanup(run):
    deadline = time.monotonic() + 60
    snapshots = []
    while True:
        apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader,nounits'], text=True)
        snapshots.append({'monotonic':time.monotonic(), 'processes':apps})
        if not apps.strip(): break
        if time.monotonic() >= deadline:
            (run / 'cleanup_wait.json').write_text(json.dumps({'status':'failed','snapshots':snapshots}, indent=2))
            raise RuntimeError('GPU contexts remain after PAP cleanup deadline')
        time.sleep(1)
    (run / 'gpu_processes_after.csv').write_text(apps)
    (run / 'cleanup_wait.json').write_text(json.dumps({'status':'passed','snapshots':snapshots}, indent=2))

reference = json.loads(Path('/home/fei/research/PD/vllm-pap/benchmarks/pap/experiments/e2e/PAP-20260907-ALIGNED-C30/runs/20260907T020755Z/pap_source_reference.json').read_text())['source_sha256']
assert all(digest(ROOT / name) == expected for name, expected in reference.items()), 'PAP source changed since optimization'
(OUT / 'optimized_source_reference.json').write_text(json.dumps(reference, indent=2))

assert digest(DATA) == EXPECTED_DATA
for name, expected in MANIFEST.items():
    assert digest(ROOT / name) == expected, f'concurrent source change: {name}'
for mode in ('pap1', 'pap2'):
    assert all(digest(ROOT / name) == expected for name, expected in reference.items()), 'PAP source changed during experiment'
    run = OUT / f'run_{mode}'
    run.mkdir()
    gpu_text = subprocess.check_output(['nvidia-smi', '--query-gpu=index,uuid,memory.used', '--format=csv,noheader,nounits'], text=True)
    (run / 'gpu_before.csv').write_text(gpu_text)
    gpus = [line.split(', ') for line in gpu_text.strip().splitlines()]
    assert len(gpus) == 8 and all(int(row[2]) < 100 for row in gpus), gpu_text
    gpu_apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader,nounits'], text=True)
    (run / 'gpu_processes_before.csv').write_text(gpu_apps)
    assert not gpu_apps.strip(), 'GPU has an active context, including an idle MPS server'
    assert not processes(), 'background serving process or benchmark client'
    uuids = {int(row[0]): row[1] for row in gpus}
    applied = {}
    proc = None
    try:
        for name, expected in MANIFEST.items():
            assert digest(ROOT / name) == expected, f'concurrent source change: {name}'
            shutil.copyfile(OUT / mode / name, ROOT / name)
            applied[name] = digest(ROOT / name)
        shutil.copyfile(OUT / f'{mode}.env', run / 'requested.env')
        with (run / 'instrumented_source.patch').open('w') as log:
            subprocess.run(['git', 'diff', '--binary'], cwd=ROOT, stdout=log, check=True)
        env = {'HOME': os.environ['HOME'], 'USER': os.environ.get('USER', 'fei'), 'PATH': os.environ['PATH'], 'LANG': 'C.UTF-8', 'RUN_ROOT': str(run), 'RUN_LOG_DIR': str(run / 'service_logs'), 'PAP_AIPERF_OUTPUT_DIR': str(run / 'aiperf')}
        command = ['bash', '-c', 'set -a; source "$1"; set +a; exec bash "$2"', 'pap-ab', str(run / 'requested.env'), str(ROOT / 'benchmarks/pap/scripts/run_pap_workload.sh')]
        (run / 'launch.json').write_text(json.dumps({'command': command, 'env': env, 'cwd': str(ROOT), 'source_sha256': applied}, indent=2))
        with (run / 'runner.log').open('w') as log:
            proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            print(f'{mode}: runner pid={proc.pid}, artifacts={run}', flush=True)
            checked = False
            deadline = time.monotonic() + 2700
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            while proc.poll() is None:
                if time.monotonic() > deadline:
                    raise TimeoutError('run deadline exceeded')
                if not checked and len(list(run.glob('runtime_cuda_context_*_*.json'))) == 14:
                    try:
                        with opener.open('http://127.0.0.1:9460/health', timeout=0.3) as response:
                            ready = response.status == 200
                    except OSError:
                        ready = False
                    if ready:
                        audit(run, uuids, proc.pid)
                        checked = True
                        print(f'{mode}: live processes and device mapping verified before client launch', flush=True)
                time.sleep(1)
            (run / 'exit_code').write_text(str(proc.returncode) + '\n')
            assert proc.returncode == 0, f'{mode} runner failed: {proc.returncode}; {run / "runner.log"}'
            assert checked, 'run lacks live topology audit'
            print(f'{mode}: completed successfully', flush=True)
    except BaseException as exc:
        (run / 'validation_status.json').write_text(json.dumps({'status': 'invalid', 'reason': repr(exc)}, indent=2))
        raise
    finally:
        if proc is not None and proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=240)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
        for name, expected in applied.items():
            if digest(ROOT / name) != expected:
                raise RuntimeError(f'concurrent source edit; refused to overwrite {name}')
            shutil.copyfile(OUT / 'final_source' / name, ROOT / name)
        wait_for_gpu_cleanup(run)
print('Both clean PAP runs complete; final production sources restored without instrumentation.', flush=True)
