from pathlib import Path
import json,subprocess,time
root=Path('/home/fei/research/PD/vllm-pap');out=Path('/tmp/pap-aligned-baselines.an6e3tbl')
deadline=time.monotonic()+7200
print('Waiting for all aligned DP/PD repetitions and GPU cleanup audits.',flush=True)
while True:
 log=(out/'driver-aligned.log').read_text()
 if 'Traceback (most recent call last)' in log:raise RuntimeError('Aligned baseline driver failed; PAP comparison not started')
 done='All four architectures completed two audited runs' in log
 if done:
  for arch in ['dp8','6p2d','4p4d','2p6d']:
   for rep in [1,2]:
    r=out/f'runs_aligned/{arch}_r{rep}'
    assert json.loads((r/'completion_audit.json').read_text())['status']=='passed'
    assert json.loads((r/'cleanup_wait.json').read_text())['status']=='passed'
  break
 if time.monotonic()>deadline:raise TimeoutError('Baseline completion deadline exceeded')
 time.sleep(1)
print('Aligned DP/PD complete; starting two clean PAP reference runs.',flush=True)
with (out/'pap_clean/driver.log').open('w') as log:
 subprocess.run([str(root/'.venv/bin/python'),str(out/'pap_clean/run.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Clean PAP reference runs completed.',flush=True)
