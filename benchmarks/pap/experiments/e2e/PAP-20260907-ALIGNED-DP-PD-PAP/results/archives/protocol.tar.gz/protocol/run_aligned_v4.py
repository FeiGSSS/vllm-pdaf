from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import signal
import subprocess
import time

ROOT = Path('/home/fei/research/PD/vllm-pap')
OUT = Path('/tmp/pap-aligned-baselines.an6e3tbl')
DATA = ROOT / 'benchmarks/pap/datasets/agentic-code/s60-t3-native32k-stratified-seed42/dataset.jsonl'
DATA_SHA = '5d4357a9a037e9e1a3c25acf402ba06afd1c9e7643678da225b9f5cc63cb257c'
RUNS = OUT / 'runs_v3'
RUNS.mkdir(exist_ok=True)
ARCHS = {'dp8': (8,0,0), '6p2d': (0,6,2), '4p4d': (0,4,4), '2p6d': (0,2,6)}
BASE = {
 'MODEL_PATH':'/data/ssd1/llm-models/Qwen3-8B',
 'DYNAMO_MAX_MODEL_LEN':'32768', 'DYNAMO_HF_OVERRIDES':'',
 'DYNAMO_AGG_MAX_NUM_BATCHED_TOKENS':'2048',
 'DYNAMO_PREFILL_MAX_NUM_BATCHED_TOKENS':'2048',
 'DYNAMO_DECODE_MAX_NUM_BATCHED_TOKENS':'256',
 'DYNAMO_MAX_NUM_SEQS':'256', 'DYNAMO_BLOCK_SIZE':'16',
 'DYNAMO_GPU_MEMORY_UTILIZATION':'0.90',
 'DYNAMO_AGG_ASYNC_SCHEDULING':'on',
 'DYNAMO_PREFILL_ASYNC_SCHEDULING':'off',
 'DYNAMO_DECODE_ASYNC_SCHEDULING':'on',
 'DYNAMO_USE_V2_MODEL_RUNNER':'1',
 'DYNAMO_AGG_CUDAGRAPH_CAPTURE_SIZES':'1,2,4,8,16,32,64,128',
 'DYNAMO_PREFILL_CUDAGRAPH_CAPTURE_SIZES':'1,2,4,8,16,32,64,128',
 'DYNAMO_DECODE_CUDAGRAPH_CAPTURE_SIZES':'1,2,4,8,16,32,64,128',
 'DYNAMO_CLUSTER_READY_WAIT_SECONDS':'30',
 'DYNAMO_ROUTER_MODE':'kv', 'DYNAMO_DISCOVERY_BACKEND':'etcd',
 'DYNAMO_START_ETCD':'1', 'DYNAMO_SMOKE_ONLY':'0',
 'DYNAMO_AIPERF_INPUT_FILE':str(DATA), 'DYNAMO_AIPERF_INPUT_SHA256':DATA_SHA,
 'DYNAMO_AIPERF_SESSIONS':'60', 'DYNAMO_AIPERF_CONCURRENCY':'60',
 'DYNAMO_AIPERF_EXPECTED_REQUESTS':'180', 'DYNAMO_AIPERF_TIMING_MODE':'concurrency',
 'DYNAMO_AIPERF_REQUEST_RATE':'', 'DYNAMO_AIPERF_ARRIVAL_PATTERN':'poisson',
 'DYNAMO_AIPERF_CUSTOM_DATASET_TYPE':'mooncake-trace',
 'DYNAMO_AIPERF_WARMUP_DURATION_SECONDS':'0',
 'DYNAMO_AIPERF_BENCHMARK_DURATION_SECONDS':'',
 'DYNAMO_AIPERF_BENCHMARK_GRACE_PERIOD_SECONDS':'0',
 'DYNAMO_AIPERF_REQUEST_TIMEOUT_SECONDS':'21600',
 'DYNAMO_MIN_KV_TRANSFER_MB_S':'5000',
}

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def read_env(p):
    out={}
    for line in p.read_text().splitlines():
        if not line or line.startswith('#'): continue
        k,v=line.split('=',1); values=shlex.split(v); assert len(values)==1,(k,v);out[k]=values[0]
    return out

def write_env(p, values):
    p.write_text(''.join(f'{k}={shlex.quote(str(v))}\n' for k,v in values.items()))

def processes():
    rows=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            args=[v for v in (p/'cmdline').read_bytes().decode().split('\0') if v]
            cmd=' '.join(args)
            if not any(s in cmd for s in ('dynamo.vllm','dynamo.frontend','dynamo-frontend','VLLM::EngineCore','vllm.pap.service','vllm.pap.gateway','/bin/vllm serve','/bin/aiperf')):continue
            env=dict(x.split('=',1) for x in (p/'environ').read_bytes().decode().split('\0') if '=' in x)
            selected={k:env[k] for k in ('CUDA_VISIBLE_DEVICES','VLLM_USE_V2_MODEL_RUNNER','CUDA_MPS_SM_PARTITION','CUDA_MPS_PIPE_DIRECTORY','DYN_NAMESPACE') if k in env}
            ancestors=[]; parent=int(p.name)
            while parent>1:
                parent=int(Path(f'/proc/{parent}/stat').read_text().rsplit(')',1)[1].split()[1]);ancestors.append(parent)
            rows.append({'pid':int(p.name),'argv':args,'command':cmd,'env':selected,'ancestors':ancestors})
        except (OSError,UnicodeError,ValueError):continue
    return rows

def gpu_snapshot(run):
    raw=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.used','--format=csv,noheader,nounits'],text=True)
    (run/'gpu_before.csv').write_text(raw)
    gpus=[line.split(', ') for line in raw.strip().splitlines()]
    assert len(gpus)==8 and all(int(r[3])<100 and 'L20' in r[2] for r in gpus),raw
    apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader,nounits'],text=True)
    (run/'gpu_processes_before.csv').write_text(apps)
    assert not apps.strip(), 'GPU has an active context, including an idle MPS server'
    return {int(r[0]):r[1] for r in gpus}

def wait_for_gpu_cleanup(run):
    deadline=time.monotonic()+60
    snapshots=[]
    while True:
        apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader,nounits'],text=True)
        snapshots.append({'monotonic':time.monotonic(),'processes':apps})
        if not apps.strip():break
        if time.monotonic()>=deadline:
            (run/'cleanup_wait.json').write_text(json.dumps({'status':'failed','snapshots':snapshots},indent=2))
            raise RuntimeError('GPU contexts remain after cleanup deadline; refusing to continue')
        time.sleep(1)
    (run/'gpu_processes_after.csv').write_text(apps)
    (run/'cleanup_wait.json').write_text(json.dumps({'status':'passed','snapshots':snapshots},indent=2))

def arg(args,key):
    assert args.count(key)==1,(key,args)
    return args[args.index(key)+1]

def audit(run, arch, runner_pid, uuids):
    rows=processes();(run/'process_topology.json').write_text(json.dumps(rows,indent=2))
    assert all(runner_pid in r['ancestors'] for r in rows),'foreign serving process'
    assert not any('/bin/aiperf' in r['command'] for r in rows),'client started before audit'
    workers=[r for r in rows if '-m' in r['argv'] and arg(r['argv'],'-m')=='dynamo.vllm']
    engines=[r for r in rows if 'VLLM::EngineCore' in r['command']]
    assert len(workers)==8 and len(engines)==8,(len(workers),len(engines))
    raw=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader,nounits'],text=True)
    (run/'gpu_processes.csv').write_text(raw)
    gpu_pids={int(v[0]):v[1] for v in (line.split(', ') for line in raw.strip().splitlines()) if len(v)==2}
    all_owned={r['pid'] for r in rows}
    assert set(gpu_pids)<=all_owned,('GPU context outside audited service processes',set(gpu_pids)-all_owned)
    counts={'aggregated':0,'prefill':0,'decode':0};mapping=[];devices=set()
    for w in workers:
        args=w['argv'];role=arg(args,'--disaggregation-mode') if '--disaggregation-mode' in args else 'aggregated'
        counts[role]+=1;gpu=int(w['env']['CUDA_VISIBLE_DEVICES']);devices.add(gpu)
        for flag,value in [('--model',BASE['MODEL_PATH']),('--dtype','float16'),('--tensor-parallel-size','1'),('--max-model-len','32768'),('--max-num-seqs','256'),('--block-size','16'),('--gpu-memory-utilization','0.90'),('--generation-config','vllm')]:
            assert arg(args,flag)==value,(role,flag)
        budget='256' if role=='decode' else '2048';assert arg(args,'--max-num-batched-tokens')==budget
        assert '--enable-chunked-prefill' in args and '--enable-prefix-caching' in args
        assert '--hf-overrides' not in args
        scheduling='off' if role=='prefill' else 'on'
        assert ('--no-async-scheduling' in args)==(scheduling=='off')
        assert ('--async-scheduling' in args)==(scheduling=='on')
        compilation=json.loads(arg(args,'--compilation-config'))
        assert compilation['cudagraph_mode']=='PIECEWISE' and compilation['cudagraph_capture_sizes']==[1,2,4,8,16,32,64,128]
        assert w['env']['VLLM_USE_V2_MODEL_RUNNER']=='1' and 'CUDA_MPS_SM_PARTITION' not in w['env']
        children=[r for r in engines if w['pid'] in r['ancestors']];assert len(children)==1,(role,w['pid'],len(children))
        e=children[0];assert gpu_pids.get(e['pid'])==uuids[gpu],(e['pid'],gpu_pids,uuids[gpu])
        if role=='prefill':assert gpu<ARCHS[arch][1]
        if role=='decode':assert gpu>=ARCHS[arch][1]
        mapping.append({'role':role,'worker_pid':w['pid'],'engine_pid':e['pid'],'gpu':gpu,'uuid':uuids[gpu],'token_budget':int(budget),'async_scheduling':scheduling})
    assert devices==set(range(8)) and tuple(counts[k] for k in ('aggregated','prefill','decode'))==ARCHS[arch]
    assert 'STATUS=passed' in (run/'vllm_cuda_graph_audit.env').read_text()
    (run/'startup_audit.json').write_text(json.dumps({'status':'passed','counts':counts,'engine_count':8,'mapping':mapping},indent=2))

assert digest(DATA)==DATA_SHA
tracked=['benchmarks/pap/scripts/run_dynamo_workload.sh','benchmarks/pap/scripts/run_aiperf_profile.sh','benchmarks/pap/scripts/configure_same_node_nixl.sh']
source_hashes={p:digest(ROOT/p) for p in tracked}
(OUT/'source_manifest.json').write_text(json.dumps(source_hashes,indent=2));write_env(OUT/'common.env',BASE)
for repetition,architectures in [(1,list(ARCHS)),(2,list(reversed(ARCHS)))]:
    for arch in architectures:
        for p,h in source_hashes.items():assert digest(ROOT/p)==h,('source changed',p)
        run=RUNS/f'{arch}_r{repetition}'
        if (run/'completion_audit.json').exists():
            assert json.loads((run/'completion_audit.json').read_text())['status']=='passed'
            assert (run/'exit_code').read_text().strip()=='0'
            cfg=read_env(run/'effective_config.env')
            for k,v in BASE.items():assert cfg.get(k)==v,(k,cfg.get(k),v)
            wait_for_gpu_cleanup(run)
            print(f'{arch} r{repetition}: preserving completed audited result',flush=True)
            continue
        run.mkdir();proc=None
        try:
            uuids=gpu_snapshot(run);assert not processes(),'background service or client'
            values=dict(BASE) if repetition==1 else read_env(RUNS/f'{arch}_r1/effective_config.env')
            values.update({'DYNAMO_ARCHITECTURE':arch,'DYNAMO_RUN_ID':f'aligned_{arch}_r{repetition}_{OUT.name}', 'DYNAMO_RUN_ROOT':str(run),'DYNAMO_AIPERF_OUTPUT_DIR':str(run/'aiperf'),'DYNAMO_NAMESPACE':f'pap-aligned-{arch}-r{repetition}-{OUT.name.replace(chr(46),chr(45))}','DYNAMO_FILE_KV':str(run/'discovery')})
            for k,v in BASE.items():assert values.get(k)==v,(arch,k,values.get(k),v)
            write_env(run/'requested.env',values)
            env={'HOME':os.environ['HOME'],'USER':os.environ.get('USER','fei'),'PATH':os.environ['PATH'],'LANG':'C.UTF-8','UV_CACHE_DIR':'/tmp/uv-cache-pap-baselines'}
            command=['bash','-c','set -a; source "$1"; set +a; exec bash "$2"','aligned-baseline',str(run/'requested.env'),str(ROOT/'benchmarks/pap/scripts/run_dynamo_workload.sh')]
            (run/'launch.json').write_text(json.dumps({'command':command,'env':env,'source_sha256':source_hashes,'replayed_from':None if repetition==1 else str(RUNS/f'{arch}_r1/effective_config.env')},indent=2))
            with (run/'runner.log').open('w') as log:
                proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                print(f'{arch} r{repetition}: runner {proc.pid}; {run}',flush=True)
                checked=False;deadline=time.monotonic()+3600
                while proc.poll() is None:
                    if time.monotonic()>deadline:raise TimeoutError('run deadline exceeded')
                    graph=run/'vllm_cuda_graph_audit.env'
                    if not checked and graph.exists() and 'STATUS=passed' in graph.read_text():
                        audit(run,arch,proc.pid,uuids);checked=True
                        print(f'{arch} r{repetition}: actual workers, devices and scheduling verified before client launch',flush=True)
                    time.sleep(1)
            (run/'exit_code').write_text(str(proc.returncode)+'\n')
            assert proc.returncode==0,('runner failed',proc.returncode,run)
            assert checked,'no live startup audit'
            cfg=read_env(run/'effective_config.env')
            for k,v in BASE.items():assert cfg.get(k)==v,('effective configuration mismatch',k,cfg.get(k),v)
            rs=[json.loads(x) for x in (run/'aiperf/profile.jsonl').read_text().splitlines()];assert len(rs)==180
            for name in ['correctness_audit.env','vllm_cuda_graph_audit.env']:
                assert 'STATUS=passed' in (run/name).read_text(),name
            transfer=(run/'kv_transfer_audit.env').read_text();assert ('STATUS=not_applicable' if arch=='dp8' else 'STATUS=passed') in transfer
            (run/'completion_audit.json').write_text(json.dumps({'status':'passed','requests':180,'configuration_matches_requested':True,'effective_config_replay':repetition==2},indent=2))
            print(f'{arch} r{repetition}: complete, 180 requests and all audits passed',flush=True)
        except BaseException as exc:
            (run/'invalidated.json').write_text(json.dumps({'status':'invalidated','error':f'{type(exc).__name__}: {exc}'},indent=2));raise
        finally:
            if proc is not None and proc.poll() is None:
                os.killpg(proc.pid,signal.SIGTERM)
                try:proc.wait(timeout=240)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid,signal.SIGKILL);proc.wait()
            wait_for_gpu_cleanup(run)
print('All four architectures completed two audited runs; second round replayed saved effective configurations.',flush=True)
