from pathlib import Path
import json,re
root=Path('/tmp/pap-aligned-baselines.an6e3tbl');statefile=root/'status-cursors.json';state=json.loads(statefile.read_text()) if statefile.exists() else {}
paths=[root/'driver-aligned.log']
if paths[0].exists():
 text=paths[0].read_text();matches=re.findall(r'(?:dp8|6p2d|4p4d|2p6d) r[12]: runner \d+; (.+)',text)
 if matches:paths.append(Path(matches[-1])/'runner.log')
if (root/'pap_clean/driver.log').exists():
 paths.append(root/'pap_clean/driver.log')
 for run in ['run_pap1','run_pap2']:
  p=root/'pap_clean'/run/'runner.log'
  if p.exists():paths.append(p)
for p in paths:
 if not p.exists():continue
 key=str(p);size=p.stat().st_size;offset=state.get(key,0)
 if offset>size:offset=0
 with p.open('rb') as f:f.seek(offset);data=f.read()
 state[key]=size
 lines=data.decode(errors='replace').splitlines()
 chosen=[s for s in lines if p.name.startswith('driver') or re.search(r'Phase profiling|Sent 180|ERROR:|RUN_ROOT=|RUN_ROOT/|GPU.*audit passed|Dynamo frontend registered|PAP Gateway is ready',s)]
 if chosen:print(p.parent.name+'/'+p.name+'\n'+'\n'.join(chosen[-12:]))
statefile.write_text(json.dumps(state,indent=2))
