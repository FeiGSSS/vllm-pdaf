PAP TTFT / TBT 优化记录，2026-09-07

本轮交付是代码与部署配置的组合。最终独立复测中，平均 TTFT、平均 TBT 和 TTFT p95 均改善；TTFT p50 有回退。不能声称所有请求、所有分位数或其他负载均会改善。

| 客户端指标 | 优化前 | 优化后 | 变化 |
| --- | ---: | ---: | ---: |
| 平均 TTFT | 15.59 s | 13.80 s | 降低 11.5% |
| 平均 TBT | 55.81 ms | 43.86 ms | 降低 21.4% |
| TTFT p95 | 27.54 s | 18.93 s | 改善 |
| TTFT p50 | 13.26 s | 14.32 s | 回退 |

这组数字来自 [最终对照结果](confirmation_ab/comparison.json)，每边 180 个请求。TTFT 是客户端发起请求至收到首 token 的时间；TBT 使用 AIPerf 的逐请求 inter_token_latency，再对请求取平均。它们不是内部控制排队时间，也不是全局输出 cadence。

模型 Qwen3-8B FP16，7PA1P，8 张 L20：GPU 0–6 各 Prefill 80 SM / Attention 12 SM，GPU 7 Projection；Prefill 同步调度、Projection 异步调度。并发 60，会话 60，每会话 3 轮，共 180 请求；上下文上限 32768。各次启动均核验了 14 个实际 CUDA context、8 个 EngineCore、7 个 Attention 进程及设备 UUID，排除了其他服务和客户端。

输入数据文件、种子、并发、输入模板和每个请求的输出长度均一致。原始输入 SHA256 为 `5d4357a9a037e9e1a3c25acf402ba06afd1c9e7643678da225b9f5cc63cb257c`，AIPerf materialized input SHA256 为 `ece4ff1e413301990a84a1a4f43b7a65ae45b150c023a2f43e725c99ef7032c5`。这是实际多轮反馈负载，后续轮次会追加模型生成内容，因此不把全部后续 prompt 声称为逐字节相同。此次总输入 token 数为 3,372,705 / 3,371,858。

保留了以下实现与配置：

- Prefill 每轮总 token 预算 `PAP_PREFILL_MAX_NUM_BATCHED_TOKENS=32768 → 2048`。完整上下文和生成长度不变；这是当前负载的选择，不是所有模型的通用最优值。
- [Gateway 启动预热](/home/fei/research/PD/vllm-pap/vllm/pap/gateway/tokenizer.py:71)：复用 vLLM renderer 的标准 warmup，避免第一批并发请求重复初始化 processor / chat template。
- [QKV 打包与输出拆包](/home/fei/research/PD/vllm-pap/vllm/pap/transport/nvshmem/device_bridge.cu:118)：地址和行长度满足对齐时用 16-byte 向量复制；未对齐输入保留原字节路径。信号、屏障、路由和 ABI 不变。
- [安全提前回收](/home/fei/research/PD/vllm-pap/vllm/pap/integration/engine.py:242)：Attention 完成 token/KV join，并提交最终 commit 序号；Prefill 核验 applied 序号后解除租约；在同步 EngineCore 边界完成 GPU fence 和 worker 完成确认，再通过 Scheduler 的正常 finished_sending 路径归还引用。下一次 Prefill admission 可以看到归还后的块。
- [Connector 完成状态](/home/fei/research/PD/vllm-pap/vllm/pap/kv_connector.py:167)：防止提前回收后，下次正常 worker 回调重复报告完成；同时清理 Scheduler connector 中的旧 owner 元数据。最终运行核验了 [180 个唯一请求的实际回收](confirmation_ab/run_optimized/allocator_reclaim_audit.json)。
- 最终 commit 未提交或 join 失败时保留 Attention session 并报错；重复 release 不会错误地触发 commit 顺序异常。

租约的正常路径现在是：已提交的 Prefill GPU batch 完成 → EngineCore 处理 commit/release → 校验最终 commit → worker fence/确认 → allocator 引用归还 → 下一次 Prefill 调度。正在运行的长 Prefill 仍可能阻塞控制消息；本轮没有消除这段等待。异步 Prefill 使用原回收路径，不启用提前回收。

对 Prefill 预算做过同代码、单变量对照：

| Prefill 每轮总 token 上限 | 平均 TTFT | 平均 TBT |
| ---: | ---: | ---: |
| 32768 | 16.03 s | 48.79 ms |
| 8192 | 14.76 s | 45.51 ms |
| 2048 | 14.32 s | 42.15 ms |

见 [2048 对照](prefill_slice_ab_v2/comparison_2k.json)、[8192 对照](prefill_slice_ab_v2/comparison_8k.json)。这一对照把配置收益与代码收益分开了。预算降低也改变了 activation 显存预算及 KV 容量：32768 时每个 Prefill 可容纳约 14.7–15.1 万 KV tokens，2048 时约 16.7–17.1 万，见 [逐 rank 启动证据](prefill_slice_ab_v2/kv_capacity_comparison.json)。不能把全部收益归因于控制排队缩短。

保持 32768 时，代码组合的四轮正反顺序复测平均 TTFT 降低 9.8%，TBT 平均增加约 1.1%，没有证明 TBT 获益，见 [A 组](final_abba/comparison_a.json)、[B 组](final_abba/comparison_b.json)。最终性能结论必须包含 2048 的配置条件。

未保留强制 Triton 和增加控制并发的方案。前者 TBT 回退约 10%；后者在完整提前回收组合中 TBT 回退约 3.4%。控制仍串行处理，不绕过 commit 顺序和 GPU 生命周期约束。

验证结果：

- [131 项 PAP 测试通过](final-tests.log)，包含顺序、重复 release、失败不释放、同步边界、重复完成抑制及 NVSHMEM 启动契约。
- [66 项 Gateway / renderer 测试通过](final-gateway-tests.log)。
- [16 个 CUDA 复制测试场景](vector_copy/vector_probe_extended.json)逐字节一致，覆盖空批、单行、满批、未对齐行长度和未对齐地址。代表性打包约 74 → 11 μs、拆包约 63 → 6 μs，是局部测试数据，不直接等于端到端收益。
- Ruff 与 clang-format 通过。原始测试日志、源码与 [优化改动补丁](final_abba/optimization_only.patch)均保留。基线已包含之前的 commit 身份修复；补丁仅列本轮新增优化，不把工作区其他修改混为本轮优化。
- 最终对照每边 180 请求通过 correctness、decode-token join、session drain、routing 审计。两个 2048 运行的平均 TBT 分别为 42.15 ms、43.86 ms。

完整有效配置在 [recommended-effective.env](recommended-effective.env)，最初请求配置在 [recommended-requested.env](recommended-requested.env)。重放时仅分配新的输出目录，其他有效配置原样载入：

```bash
cd /home/fei/research/PD/vllm-pap
set -a
source /tmp/pap-client-latency.CiVHjy/recommended-effective.env
RUN_ROOT="$(mktemp -d /tmp/pap-optimized.XXXXXX)"
RUN_LOG_DIR="${RUN_ROOT}/service_logs"
PAP_AIPERF_OUTPUT_DIR="${RUN_ROOT}/aiperf"
set +a
bash benchmarks/pap/scripts/run_pap_workload.sh
```

[最终源码核验](final_source_audit.json)记录已测版本的哈希。配置文件依赖当前已测工作区、模型路径与数据文件；不能拿不同源码版本沿用本报告性能结论。

原始诊断另存于 `diagnostic_v3/` 与 `nsys_diagnostic/`。Nsight 只捕获到 7 个 Attention 与 1 个 Projection 的 CUDA kernel，缺少 Prefill kernel 时间；没有用该 trace 推断 Prefill GPU 利用率。临时租约 trace 已从生产源码移除。
